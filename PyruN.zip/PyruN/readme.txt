run.sh başlatıcı oluşturup panele sabitleyin icon resmini dosya içerisindeki resim yapabilirsiniz.
gui de music e tıklamak için sox indirmeniz lazım 

sudo apt-get install sox
sudo apt-get install sox libsox-fmt-all

kaynak koddan music buttonunu aktifleştirmeniz lazım 
yalnız music e tıkladıktan sonra arayüz donuyor haberiniz olsun çok darlanmadıysanız basmayın ayrıca çalıştırdığınız kodda sonsuz döngüye girersede donuyor terminalden Ctrl+C yaparak durumu düzeltebilirsiniz
kodlarınızı editlemek için de gedit komutu kullandım siz hangi metin editörünü kullanıyorsanız onuda kaynak koddan komut verilmiş yerden düzeltebilirsiniz
sizde root klasörü home klasörü olmayabilir aynı zamanda Desktopunuz hangi klasör altındaysa onuda kaynak koddan path vermiş olduğum yerlerden değiştirebilirsiniz.

herhangi bir sorun yaşarsanız kylin11235@gmail.com dan bana ulaşabilirsiniz.
