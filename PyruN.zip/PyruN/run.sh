cd 
cd Desktop/PyruN
python3 pyrunner.py
