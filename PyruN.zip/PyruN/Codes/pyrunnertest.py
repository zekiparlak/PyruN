import os
sum = 0
for i in range(1,11):
    os.system("clear")
    i = str(i)
    x = int(input(i + ". sayı gir :"))
    sum = sum + x
avg = sum / 10
print("Ortalama = ",avg) 
