from tkinter import *
window = Tk()
window.geometry("400x400")
for i in range(10):
    i = str(i)
    b = Button(text = i)
    b.pack()
window.mainloop()
