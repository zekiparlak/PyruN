import random
import os
import time
x = 99
matrix = [[0 for x in range(x)] for y in range(x)]
rand = list(range(x))
str = ["!", "#", "%","+", "Q", "W", "X", "?", "(", ")", "{", "}", "&", "$", "*", "-", "/", "[", "]", "=", "-","^"]
while True:
    os.system("clear")
    for i in range(x):
        rand[i] = random.randint(0,x-2)
    for i in range(x):
        for j in range(x):
            if i < rand[j]:
                matrand = random.randint(0,21)
                matrix[i][j] = str[matrand]
                print(matrix[i][j],"",end="",flush=True)
            else:
                matrix[i][j] = " "
                print(matrix[i][j],"",end="",flush=True)
            #time.sleep(1/10)
        print()
        time.sleep(1/35)
    #time.sleep(1/3)
